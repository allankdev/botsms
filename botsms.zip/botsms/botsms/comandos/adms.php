<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Meus adms no momento sao: @draftinfcc </b>",
	'parse_mode' => 'html'
]);
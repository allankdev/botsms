<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Meu Fundador e criador: @draftinfcc</b>",
	'parse_mode' => 'html'
]);
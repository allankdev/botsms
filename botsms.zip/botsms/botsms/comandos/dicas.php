<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>Algumas dicas para usar o bot:</b>\n🔸 O bot não cria códigos de SMS. Você precisa registrar o número no serviço desejado para que o bot receba o SMS enviado para ele.
    \n\n🔸 Os números só recebem SMS do serviço para o qual foram comprados. Para outros serviços, use a opção 'Outros'.
    \n🔸 Para evitar problemas com segurança ao usar números temporários, siga estas dicas:
    • Use uma VPN com o mesmo IP do país do número.
    • Limpe os dados do aplicativo.
    • Evite usar emuladores.
    • Use o navegador em modo anônimo e limpe o cache e os cookies.
    • Não tente usar o mesmo número, IP ou dispositivo muitas vezes.
    • Use os números apenas em aplicativos ou sites oficiais.
 \n\n🔸 Alguns números podem não funcionar porque foram desativados pela operadora. Isso é normal. Você pode cancelar ou trocar o número. O bot só cobra quando você recebe o SMS.\nNão, os números são descartaveis/temporarios, após o uso eles são substituidos por novos, servindo somente para confirmação ou criação de cadastros.\n\n🔸 Mantenha a segurança dos seus cadastros em aplicativos, serviços e sites. Não somos responsáveis por qualquer perda ou dano após o uso dos números. Você é responsável pelos registros feitos com os números.\nO saldo é adicionado automaticamente na sua conta.\n\n🔸 Use /alertas se o serviço estiver sem números. Você será avisado quando chegarem novos números. Todos os serviços são atualizados ao longo do dia.\n🔸 Evite cancelar muitos números, pois você pode ser penalizado com perda de saldo e bloqueio. Siga as dicas para usar bem os números.
 <em>• Veja como o bot funciona com um exemplo: <a href='http://www.youtube.com/@smsgoshopbot'>clicando aqui</a>.</em>", 
	'parse_mode' => 'html'
]);

﻿<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "😀 <b>Olá ".htmlentities ($tlg->FirstName ())."</b>, Aqui você pode gerar números temporários para receber SMS de qualquer serviço, aplicativo ou site.\n\nTemos um sistema de afiliados onde você pode ganhar saldo indicando. Para mais informações, utilize /afiliados. Mas antes, explore o menu abaixo para entender como tudo funciona.\n\n ⚠️ Também é essencial que você leia nossos termos de uso utilizando /sobre antes de utilizar o bot.\n\n<b><em><a href=\"https://t.me/canalsmsgoshop\"> Acesse nosso canal 😀 </a></em></b>",
	'parse_mode' => 'html',
	'disable_web_page_preview' => false,
	'reply_markup' => $tlg->buildInlineKeyboard ([
			[$tlg->buildInlineKeyBoardButton ('💵Recarregar', null, '/recarregar'),$tlg->buildInlineKeyBoardButton ('🔥Serviços', null, '/servicos')],[$tlg->buildInlineKeyBoardButton ('👤Saldo', null, '/saldo'),$tlg->buildInlineKeyBoardButton ('👥 Informações', null, '/sobre')],[$tlg->buildInlineKeyBoardButton ('🚩 Países', null, '/paises')],[$tlg->buildInlineKeyBoardButton ('📖 Como usar o bot', null, '/dicas')]
		])
]);

// afiliados
if (isset ($complemento) && is_numeric ($complemento) && STATUS_AFILIADO){

	$ref = $tlg->getUsuarioTlg ($complemento);

	// se usuario existir e não tiver entrado no bot por indicação de alguem e tambem não pode ser ele mesmo
	if (isset ($ref ['id']) && $bd_tlg->checkReferencia ($tlg->UserID ()) == false && $complemento != $tlg->UserID ()){

		// salva usuario atual como referencia do dono do link
		$bd_tlg->setReferencia ($complemento, $tlg->UserID ());

	}

}
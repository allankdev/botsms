<?php

$tlg->sendMessage ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>No momento os bots ofcs sao: @TopSms_storebot",
	'parse_mode' => 'html'
]);
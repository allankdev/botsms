<?php

if ($tlg->Callback_ID() !== null) {
    // encerra carregamento do botão de callback
    $tlg->answerCallbackQuery([
        'callback_query_id' => $tlg->Callback_ID()
    ]);
}

$bonus = (BONUS == 0) ? '' : '<em><u>+'.BONUS.'% bônus</u></em>';
$valor_pagamento = 8;

if (isset($complemento)) {
    list($valor, $calculo) = explode(' ', $complemento);

    switch ($calculo) {
        case "+1":
            $valor_pagamento = ++$valor;
            break;
        case "+10":
            $valor_pagamento = $valor + 10;
            break;
        case "-10":
            $valor_pagamento = $valor - 10;
            break;
        case "-1":
            $valor_pagamento = --$valor;
            break;
        case "+50":
            $valor_pagamento = $valor + 50;
            break;
        case "-50":
            $valor_pagamento = $valor - 50;
            break;
        default:
            // Handle invalid $calculo case
            $valor_pagamento = $valor;
            break;
    }

    // Ensure valor_pagamento is within the limits
    if ($valor_pagamento < 5) {
        $valor_pagamento = 5;
    } elseif ($valor_pagamento > 100) {
        $valor_pagamento = 100;
    }
}

$dados_mensagem = [
    'chat_id' => $tlg->ChatID(),
    'text' => "🔹 Ecolha um valor de 5 a 100 reais para recarregar, <u>pagamento por PIX</u>:\n\n<b>💰Valor: R$ " . number_format($valor_pagamento, 2) . " {$bonus}</b>",
    'parse_mode' => 'html',
    'message_id' => $tlg->MessageID(),
    'disable_web_page_preview' => 'true',
    'reply_markup' => $tlg->buildInlineKeyboard([
        [
            $tlg->buildInlineKeyBoardButton('+1', null, "/recarregar {$valor_pagamento} +1"),
            $tlg->buildInlineKeyBoardButton('-1', null, "/recarregar {$valor_pagamento} -1")
        ],
        [
            $tlg->buildInlineKeyBoardButton('+10', null, "/recarregar {$valor_pagamento} +10"),
            $tlg->buildInlineKeyBoardButton('-10', null, "/recarregar {$valor_pagamento} -10")
        ],
        [
            $tlg->buildInlineKeyBoardButton('+50', null, "/recarregar {$valor_pagamento} +50"),
            $tlg->buildInlineKeyBoardButton('-50', null, "/recarregar {$valor_pagamento} -50")
        ],
        [$tlg->buildInlineKeyBoardButton('Comprar', null, "/comprar {$valor_pagamento}")]
    ])
];

if ($tlg->Callback_ID() !== null) {
    $tlg->editMessageText($dados_mensagem);
} else {
    $tlg->sendMessage($dados_mensagem);
}

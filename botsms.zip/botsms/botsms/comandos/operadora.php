<?php

// encerra carregamento do botão de callback
$tlg->answerCallbackQuery ([
	'callback_query_id' => $tlg->Callback_ID ()
]);

$codigo_servico = $complemento;

$operadoras = json_decode ($api_sms->getOperators ($user ['pais'] ?? 73), true);

$i = 1;

// asort($operadoras ['operators']);

if($user['pais'] == 73){
	// definindo as operadoras
	$botoes [][] = $tlg->buildInlineKeyBoardButton ('QUALQUER', null, "/confirmar {$codigo_servico} any");
	$botoes[1][] = $tlg->buildInlineKeyBoardButton ('VIVO', null, "/confirmar {$codigo_servico} vivo");
	$botoes[1][] = $tlg->buildInlineKeyBoardButton ('OI', null, "/confirmar {$codigo_servico} oi");
	$botoes[2][] = $tlg->buildInlineKeyBoardButton ('TIM', null, "/confirmar {$codigo_servico} tim");
	$botoes[2][] = $tlg->buildInlineKeyBoardButton ('CLARO', null, "/confirmar {$codigo_servico} claro");
}else{
	// definindo apenas a opção de qualquer
	$botoes [][] = $tlg->buildInlineKeyBoardButton ('QUALQUER', null, "/confirmar {$codigo_servico} any");
}

$botoes [][] = $tlg->buildInlineKeyBoardButton ('🔙', null, "/sms {$codigo_servico}");

$tlg->editMessageText ([
	'chat_id' => $tlg->ChatID (),
	'text' => "<b>🚩 Selecione a operadora do número:</b>",
	'message_id' => $tlg->MessageID (),
	'parse_mode' => 'html',
	'disable_web_page_preview' => 'true',
	'reply_markup' => $tlg->buildInlineKeyboard ($botoes)
]);